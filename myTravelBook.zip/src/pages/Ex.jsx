import heroLogo from '@/assets/hero.png'
import { useEffect, useRef, useState } from 'react'

export default function Ex() {
  const [page, setPage] = useState(1);
  const [list, setList] = useState([])
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const moreRef = useRef(null)

  const ALL_ITEM = Array.from(
    { length: 10 },
    (_, index) => ({
      id: index + 1,
      name: `User ${index + 1}`,
    })
  );

  const fetchItem = async (page, limit = 2) => {
    console.log(page, 'page 11111');
    
    await new Promise((resolve, reject) => {
      setTimeout(resolve, 1000);
    })
    const start = (page - 1) * limit; // 0 // 2
    const end = start + limit;  // 2 // 4
    return ALL_ITEM.slice(start, end);
  }

  useEffect(() => {
    const loadList = async () => {
      setLoading(true);
      try {
        const data = await fetchItem(page);
        console.log(data, 'data');
        
        // setList(data);
        setList((prev) => [
          ...prev, data
        ])
        if(data.length < 10) {
          setHasMore(false)
        }
      } catch (error) {
        console.log("Error: ", error);  
      }
      finally {
        setLoading(false)
      }
    }
    loadList();
  }, [loading, page])

  useEffect(() =>{    
    let obsv = new IntersectionObserver((entries, observer) => {
        console.log("start inter");
        console.log(entries, 'entries list');  
        
        entries.forEach(entry => {
          if(entry.isIntersecting && hasMore && !loading) {

            setPage((prev) => prev)
            console.log(page, "page + 1");

            // entry.target.src = entry.target.dataset.src;

            observer.unobserve(entry.target); // 
          }
        })   
      },
    )

    // const imgList = document.querySelectorAll('img');

    // console.log(imgList, 'imgList');

    // imgList.forEach(img => {obsv.observe(img)})
    if(moreRef.current) {
      obsv.observe(moreRef.current);
    }    
    console.log(moreRef.current, 'moreRef');
    

  }, [list, moreRef])

  return (

    <section>
      <div className="container">
        <div className="overflow-x-auto h-[600px]">
          page ---- {page}
          {
            list.map((item, index) => (
              <div key={index}>
                <p>{item.name}</p>
                <img 
                  src={heroLogo} 
                  alt="img" 
                  style={{ margin: "50px auto", display: "block" }} 
                  width={150}
                />
              </div>
            ))
          }
          {
            hasMore && (
              <p ref={moreRef}>Loading...</p>
            )
          }
          {
            !hasMore && (
              <p>End data...</p>
            )
          }
        </div>
      </div>
    </section>

  )
}

// if(!!window.IntersectionObserver){
//     let observer = new IntersectionObserver((entries, observer) => { 
//         // entries : Danh sách các đối tượng chúng ta theo dỏi
//         entries.forEach(entry => {
//         // Kiểm tra ảnh của chúng ta có trong vùng nhìn thấy không
//         if(entry.isIntersecting){
//                 /* Lấy dử liệu từ data-src mà chúng ta đã gán trước đó sau đó gàn vào thuộc
//                 tính src của ảnh , lúc này thì ảnh mới bắt đầu tải về  * /
//             entry.target.src = entry.target.dataset.src;
//             observer.unobserve(entry.target);
//         }
//         });
//     }, {rootMargin: "0px 0px -200px 0px"});
//     document.querySelectorAll('img').forEach(img => { observer.observe(img) });
// }
// else document.querySelector('#warning').style.display = 'block';